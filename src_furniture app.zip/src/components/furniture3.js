import React from 'react';
import couch from '../assests/img4.png';
import '../components/furniture3.css';


// Red couch 
export default function furniture3() {
  return (
    <div className='furniture3-img3'>
        <img  src={couch} alt="sofa "/>
    </div>
  )
}



