import React from 'react';
import couch from '../assests/img3.png';
import '../components/furniture4.css';

function furniture4() {
  return (
    <div className='furniture4-img4'>
      <img  src={couch} alt="sofa "/>
    </div>
  )
}

export default furniture4