import React from 'react';
import couch from '../assests/img1.png';
import '../components/furniture2.css';


// Yellow couch
export default function furniture2() {
  return (
    <div classname =" furniture2-img2 ">
      <img src={couch} alt="sofa "/>
    </div>
  )
}
