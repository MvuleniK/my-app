import React from 'react';
import couch from '../assests/img6.png';
import '../components/furniture5.css';


//black couch
function furniture5() {
  return (
    <div className='furniture5-img5'>
      <img  src={couch} alt="sofa "/>
    </div>
  )
}

export default furniture5