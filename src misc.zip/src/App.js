
// import Registration  from './components/registration';
// import Form from './components/form';
import './App.css';
import Login from "./components/login";
import Register from "./components/register";
// import '../node_modules/bootstrap/dist/css/bootstrap.css';

function App() {
  return (



    <div className="App">

      {/* Pages go here */}
      {/* <Router>
        <Switch>
            <Route path="/" component = {Login}></Route>
            <Route path="/" component = {Login}></Route>
            <Route path="/" component = {Login}></Route>
        </Switch>
      </Router> */}

      {/* testing the array */}
      <Register/>

      {/* Working Form  */}
      {/* <Form/> */}

      {/* Login */}
      {/* <Login/> */}

      {/* registation page/index page
        <Registration/> */}
    </div>
  );
}

export default App;
